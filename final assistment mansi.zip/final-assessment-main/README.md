# final-assessment

This repo consists of the Product CRUD Operations APIs as required in the final assessment.
Change your username, password and port in application.properties file as per your system.

